rootProject.name = "MediMemoSpringServer"
